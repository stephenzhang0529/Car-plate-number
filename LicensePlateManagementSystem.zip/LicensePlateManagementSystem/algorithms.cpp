#include "algorithms.h"

Node static_List[MAXSIZE];       // 静态链表
int buckets[BUCKETS];           // 桶数组

char _cityindex[14] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P'};

void radixSort(SeqList<plate*>& licensePlates, QMap<char, QPair<int, int>>& cityIndex, int maxLength)
{
    int static_size = licensePlates.Size();
    qDebug() <<licensePlates.Size();
    qDebug() <<static_size;

    for (int pos = maxLength - 1; pos >= 0; pos --)
    {
        memset(buckets, -1, sizeof(buckets));
        for(int j = 0; j < static_size; j ++)
        {
            static_List[j].data = *licensePlates.SqList_at(j);
            static_List[j].next = -1;
        }

        // 从后往前遍历，保证排序的稳定
        for(int j = static_size - 1; j >= 0; j --)
        {
            QString plateNumber = static_List[j].data->GetPlateNumber();
            int bucketIdx;

            if(pos == 0)
            {
                bucketIdx = static_List[j].data->GetPlateCity() - 'A';
            }
            else
            {
                if(pos - 1 >= plateNumber.size())
                {
                    bucketIdx = 0;
                }
                else
                {
                    char nowchar = plateNumber[pos - 1].toLatin1();

                    if(nowchar >= 'A' && nowchar <= 'Z')
                    {
                        bucketIdx = nowchar - 'A' + 11;
                    }
                    else
                    {
                        bucketIdx = nowchar - '0' + 1;
                    }
                }
            }


            // 插入桶中
            static_List[j].next = buckets[bucketIdx];
            buckets[bucketIdx] = j;
        }

        // 清空顺序表
        licensePlates.SqList_clear();

        // 将排序结果写回顺序表
        int end = 0;
        int start = 0;

        for(int i = 0; i < BUCKETS; i ++)
        {
            int p = buckets[i];

            while(p != -1)
            {
                licensePlates.SqList_push(static_List[p].data);
                p = static_List[p].next;

                // 最后一次录入确定城市索引
                if(!pos)
                {
                    end++;
                }
            }

            if(!pos && i < 26)
            {
                cityIndex['A' + i] = {start, end - 1};
                start = end;
            }
        }

    }

    licensePlates.SqList_besorted();

    qDebug()<<licensePlates.Size();
    qDebug()<<cityIndex;
}

int HalfFind(char city, QString plateNumber, QMap<char, QPair<int, int>>* cityIndex, SeqList<plate*>* licensePlates)
{
    auto l_and_r = cityIndex->value(city);
    int l = l_and_r.first, r = l_and_r.second;

    while(l < r)
    {
        int mid = (l + r) >> 1;
        if(plateNumber_cmp(plateNumber, (*licensePlates->SqList_at(mid))->GetPlateNumber()))
        {
            r = mid;
        }
        else
        {
            l = mid + 1;
        }
    }

    return l;
}

int plateFind(QString plateNumber, int city_index, QMap<char, QPair<int, int>>* cityIndex, SeqList<plate*>* licensePlates, QMap<QString, int>* Is_repeated)
{
    if(!Is_plate_right(plateNumber))
    {
        return FORMATERROR;
    }

    if(!city_index)
    {
        QList<int> findIdx;
        QStringList plateNumbers;

        for(int idx = 0; idx < 14; idx ++)
        {
            if(Is_repeated->contains(_cityindex[idx] + plateNumber) && Is_repeated->value(_cityindex[idx] + plateNumber) == 1)
            {
                findIdx.append(idx);
                QString x = QString("辽%1 ").arg(_cityindex[idx]);
                x += plateNumber;
                plateNumbers.append(x);
            }
        }

        if (findIdx.size() > 1)
        {
               QFont font = QApplication::font();
               font.setPointSize(14);
               font.setBold(true);

               QInputDialog inputDialog;

               inputDialog.setFont(font);
               inputDialog.resize(600, 400);

               inputDialog.setLabelText("请选择一个车牌号：");
               inputDialog.setWindowTitle("查询到的车牌号");
               inputDialog.setOkButtonText(QObject::tr("确定"));
               inputDialog.setCancelButtonText(QObject::tr("取消"));
               inputDialog.setComboBoxItems(plateNumbers);
               inputDialog.setTextValue(plateNumbers[0]);

               bool ok = inputDialog.exec() == QDialog::Accepted;

               if (ok)
               {
                   QString selectedPlate = inputDialog.textValue();
                   int selectedIndex = plateNumbers.indexOf(selectedPlate);
                   return HalfFind(_cityindex[findIdx[selectedIndex]], plateNumber, cityIndex, licensePlates);
                   qDebug() << "用户选择了车牌号:" << selectedPlate;
               }
               else
               {
                   return NOSELECTERROR;
               }

        }
        else if (findIdx.size() == 1)
        {
           return HalfFind(_cityindex[findIdx.first()], plateNumber, cityIndex, licensePlates);
        }
        else
        {
            return NOEXISTERROR;
        }
    }
    else
    {
        if(Is_repeated->contains(_cityindex[city_index - 1] + plateNumber) && Is_repeated->value(_cityindex[city_index - 1] + plateNumber) == 1)
        {
            return HalfFind(_cityindex[city_index - 1], plateNumber, cityIndex, licensePlates);
        }
        else
        {
            return NOEXISTERROR;
        }
    }

}

