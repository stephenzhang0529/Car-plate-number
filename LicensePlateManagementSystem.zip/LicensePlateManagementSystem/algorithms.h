#ifndef RADIXSORT_H
#define RADIXSORT_H

#define MAXSIZE 100000 // 静态链表长度
#define BUCKETS 37     // 数字10 + 字母 26 + 空1
// 错误类型
#define FORMATERROR -1      // 格式错误
#define NOSELECTERROR -2    // 未选择错误
#define NOEXISTERROR -3     // 不存在错误

#include <QDebug>
#include <QMap>
#include <QInputDialog>
#include <QMessageBox>
#include <QWidget>
#include <QFont>
#include <QApplication>
#include <QDialog>
#include "seqlist.h"
#include "plate.h"



typedef struct _Node
{
    plate* data;    // 数据域
    int next;       // 指针域，指向下一个节点
} Node;

//基数排序
void radixSort(SeqList<plate*>& licensePlates, QMap<char, QPair<int, int>>& cityIndex, int maxLength);

//二分查找
int HalfFind(char city, QString plateNumber, QMap<char, QPair<int, int>>* cityIndex, SeqList<plate*>* licensePlates);

// 查找车牌函数
int plateFind(QString plateNumber, int city_index, QMap<char, QPair<int, int>>* cityIndex, SeqList<plate*>* licensePlates, QMap<QString, int>* Is_repeated);

#endif // RADIXSORT_H
