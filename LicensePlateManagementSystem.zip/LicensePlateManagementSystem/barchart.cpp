#include "BarChart.h"

BarChart::BarChart(QObject *parent) : QObject(parent)
{
    m_pChart = new QChart();        // 创建图表
    m_pChartView = new QChartView(m_pChart);   // 创建图表视图

    m_axisX = new QValueAxis();     // 创建X轴
    m_axisY = new QValueAxis();     // 创建Y轴

    // 默认设置X轴和Y轴的范围
    setAxisXRange(0, 10);
    setAxisYRange(0, 100);
}

BarChart::~BarChart()
{
    // 清理所有的 series
    qDeleteAll(m_seriesList);
}

QChart* BarChart::getChart() const
{
    return m_pChart;
}

void BarChart::addSeries(const QString &seriesName, const QVector<qreal> &data)
{
    // 创建一个新的 QBarSet，并添加数据
    QBarSet *set = new QBarSet(seriesName);
    for (const qreal &value : data)
    {
        *set << value;
    }

    // 创建一个新的 QBarSeries，将 QBarSet 添加到系列中
    QBarSeries *series = new QBarSeries();
    series->append(set);

    // 将 QBarSeries 添加到图表中
    m_pChart->addSeries(series);
    m_seriesList.append(series);  // 存储 QBarSeries，以便稍后管理

    // 设置 X 轴和 Y 轴
    m_pChart->setAxisX(m_axisX, series);
    m_pChart->setAxisY(m_axisY, series);

    // 更新视图
    m_pChartView->update();
}

void BarChart::setAxisTitles(const QString &xTitle, const QString &yTitle)
{
    m_axisX->setTitleText(xTitle);
    m_axisY->setTitleText(yTitle);
}

void BarChart::setAxisXRange(qreal min, qreal max)
{
    m_axisX->setRange(min, max);
}

void BarChart::setAxisYRange(qreal min, qreal max)
{
    m_axisY->setRange(min, max);
}


