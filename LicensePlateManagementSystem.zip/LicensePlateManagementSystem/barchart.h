#ifndef BARCHART_H
#define BARCHART_H

#include <QtCharts>

QT_CHARTS_USE_NAMESPACE

class BarChart : public QObject
{
    Q_OBJECT
public:
    explicit BarChart(QObject *parent = nullptr);
    ~BarChart();

    // 获取图表
    QChart* getChart() const;

    // 添加一个数据系列
    void addSeries(const QString &seriesName, const QVector<qreal> &data);

    // 设置X轴和Y轴的标题
    void setAxisTitles(const QString &xTitle, const QString &yTitle);

    // 设置X轴的范围
    void setAxisXRange(qreal min, qreal max);

    // 设置Y轴的范围
    void setAxisYRange(qreal min, qreal max);

    // 设置X轴的类别
    void setAxisXCategory(QStringList categories);

private:
    QChart *m_pChart;             // 图表
    QChartView *m_pChartView;     // 图表视图
    QValueAxis *m_axisX;         // X轴
    QValueAxis *m_axisY;         // Y轴
    QVector<QBarSeries*> m_seriesList;  // 存储多个 QBarSeries
};

#endif // BARCHART_H
