#ifndef CHART_H
#define CHART_H

#include <QObject>
#include <QtCharts>

QT_CHARTS_USE_NAMESPACE

struct BarDateInfo
{
    QString qsKey;
    QVector<qreal> vecVal;
};

class Chart : public QObject
{
    Q_OBJECT
public:
    enum EType
        {
            eInvalid,       //无效
            eBarChart,      //柱状图
            ePieChart,      //饼状图
        };

        enum EColor
        {
            eBlue,          //蓝色
            eGreen,         //绿色
            eYellow,        //黄色
            ePurple,        //紫色
            eRed,           //红色
            eLightBlue,     //淡蓝色
            eLightGreen,    //淡绿色
            eLightYellow,   //淡黄色
            eLightPurple,   //淡紫色
        };
 public:
    Chart(const Chart::EType& type, QChartView* pView, QObject *parent = nullptr);
    virtual ~Chart();

public:
    //根据选择的图形，返回CMyChart
    static Chart* GetChartWithType(const EType& eType, QChartView* pView);

    //根据传入颜色转换成QColor
    QColor toQColor(const EColor& eColor);

public:
    //清空界面上显示的图形
    virtual void ClearGraphical() = 0;
    //设置提示信息是否显示
    void SetLegend(bool bLegend = true);
    //设置标题栏
    void SetTitle(const QString& qsTitle);
    //设置X轴标题
    virtual void SetAxisXTitle(const QString& qsAxisXTitle){};
    //设置Y轴标题
    virtual void SetAxisYTitle(const QString& qsAxisYTitle){};

    //柱状图添加一组数据
    virtual void AppendSeries(const QString& qsAxisXName,
                              QMap<QString, qreal>& mapData,
                              const QVector<EColor>& vecColors = m_vecDefCol){};

    //饼状图添加数据
    virtual void AppendSeries(QMap<QString, qreal>& mapData, const QVector<EColor>& vecColors = m_vecDefCol){};


public:
    EType                   m_eType;
    QChart*                 m_pChart;
    QChartView*             m_pChartView;
    static QVector<EColor>  m_vecDefCol;    //默认颜色顺序



};

#endif // CHART_H
