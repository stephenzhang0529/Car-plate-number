#include "find.h"
#include "ui_find.h"



Find::Find(QMap<QString, int>* Ir, SeqList<plate*>* lp, QMap<char, QPair<int, int>>* ci, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Find),
    licensePlates(lp),
    cityIndex(ci),
    Is_repeated(Ir),
    foundPlate(nullptr)
{
    ui->setupUi(this);

    connect(this, &Find::destroyed, this, &Find::backToMainWindow);

    QStringList cityList;
    cityList<<"  不知道"<<"  沈 阳"<<"  大 连"<<"  鞍 山"<<"  抚 顺"<<"  本 溪"<<"  丹 东"<<"  锦 州"<<"  营 口"<<"  阜 新"<<"  辽 阳"<<"  盘 锦"<<"  铁 岭"<<"  朝 阳"<<"  葫芦岛";
    ui->comboBox_city->addItems(cityList);

    QStringList deductionList;
    deductionList<<"不按规定系安全带: 1分"<<"不按规定会车: 1分"<<"不按规定使用灯光: 1分"<<"不按规定车道行驶: 3分"<<"拨打、接听手持电话: 3分"<<"不按规定超车、让行: 3分"
                <<"不按交通信号灯指示通行: 6分"<<"运输危险化学品: 6分"<<"在高速公路或者城市快速路上违法停车: 9分"<<"驾驶与准驾车型不符的机动车: 9分"
               <<"饮酒后驾驶机动车: 12分"<<"造成致人轻伤以上或者死亡的交通事故后逃逸: 12分"<<"奶龙或葛宇硕驾驶: 12分";

    deductionSelection = new QInputDialog(this);
    deductionSelection->setFont(QFont("Arial", 14, QFont::Bold));
    deductionSelection->resize(600, 400);
    deductionSelection->setComboBoxEditable(false);
    deductionSelection->setComboBoxItems(deductionList);
    deductionSelection->setLabelText("请选择要进行的扣分:");
    deductionSelection->setWindowTitle("扣分选项");
    deductionSelection->setOkButtonText(QObject::tr("确定"));
    deductionSelection->setCancelButtonText(QObject::tr("取消"));

}

Find::~Find()
{
    delete ui;
}

void Find::on_pushButton_exit_clicked()
{
    ui->lineEdit_input->clear();
    ui->textBrowser->clear();
    foundPlate = nullptr;
    emit backToMainWindow();
    this -> hide();
}

QString Find::Display(plate* findPlate)
{
    QString display = "   查询到的车牌   \n\n";
    display += QString("车牌号: 辽%1 ").arg(findPlate->GetPlateCity());
    display += findPlate->GetPlateNumber();
    display += "\n\n";
    display += QString("当前扣分: %1 分\n\n").arg(QString::number(12 - findPlate->GetPlateScore()));
    display += QString("当前状态: %1").arg(findPlate->GetPlateState());

    return display;
}

void Find::on_pushButton_find_clicked()
{
    if(!licensePlates->Issorted())
    {
        radixSort(*licensePlates, *cityIndex, 7);
        licensePlates->SqList_besorted();
    }

    if(!ui->lineEdit_input->text().isEmpty())
    {
        QString plateNumber = ui->lineEdit_input->text().toUpper();
        int city_index = ui->comboBox_city->currentIndex();

        int plateIndex = plateFind(plateNumber, city_index, cityIndex, licensePlates, Is_repeated);

        if(plateIndex == FORMATERROR)
        {
            QMessageBox::critical(this, "警告", "\n车牌错误\n", QMessageBox::Ok);
            ui->lineEdit_input->clear();
            return ;
        }
        else if(plateIndex == NOSELECTERROR)
        {
            QMessageBox::warning(this, "警告", "\n未选择车牌\n", QMessageBox::Ok);
            ui->lineEdit_input->clear();
            return ;
        }
        else if(plateIndex == NOEXISTERROR)
        {
            QMessageBox::critical(this, "警告", "\n无此车牌\n", QMessageBox::Ok);
            ui->lineEdit_input->clear();
            return ;
        }
        else
        {
            // 显示找到的车牌
            QMessageBox::information(this, "成功", "\n成功查询到该车牌\n", QMessageBox::Ok);

            plate* findPlate = *licensePlates->SqList_at(plateIndex);
            foundPlate = findPlate;
            QString display = Display(findPlate);

            ui->textBrowser->setText(display);
        }
    }
    else
    {
        ui->lineEdit_input->setFocus();
        return;
    }
}


void Find::on_pushButton_deduction_clicked()
{
    if(!foundPlate)
    {
        QMessageBox::critical(this, "警告", "\n当前未查询车牌\n", QMessageBox::Ok);
        return ;
    }
    else
    {
        if(foundPlate->Is_withdraw() == true)
        {
            QMessageBox::warning(this, "警告", "\n当前车牌已被暂扣、无法扣分\n", QMessageBox::Ok);
            return ;
        }
        bool ok = deductionSelection->exec() == QDialog::Accepted;

        if(ok)
        {
            QString selection = deductionSelection->textValue();
            if(selection[0] == "奶")
            {
                QMessageBox msgBox;
                QPixmap pixmap("F:\\QTtest\\LicensePlateManagementSystem\\geshen.jpg");
                msgBox.setIconPixmap(pixmap);
                msgBox.exec();
                return ;
            }
            else
            {
                QMessageBox::StandardButton mBox;
                mBox = QMessageBox::question(this, "询问", QString("\n是否扣分 (%1)\n").arg(selection), QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
                if(mBox != QMessageBox::Yes)
                {
                    ui->lineEdit_input->clear();
                    return ;
                }

                int deductionScore;
                QString score = selection.mid(selection.size() - 2, 1);
                if(score == "2")
                {
                    deductionScore = 12;
                }
                else
                {
                    deductionScore = score.toInt();
                }

                foundPlate->Deduction(deductionScore);
            }

            QString display = Display(foundPlate);

            ui->textBrowser->setText(display);
        }
        else
        {
            QMessageBox::warning(this, "警告", "\n未选择车牌\n", QMessageBox::Ok);
            ui->lineEdit_input->clear();
            return ;
        }
    }
}

void Find::on_pushButton_deduction_2_clicked()
{
    if(foundPlate->Is_withdraw() == false)
    {
        QMessageBox::warning(this, "警告", "\n当前车牌正常\n", QMessageBox::Ok);
        return ;
    }

    QMessageBox::StandardButton mBox;
    mBox = QMessageBox::question(this, "询问", "\n是否归还\n", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
    if(mBox != QMessageBox::Yes)
    {
        ui->lineEdit_input->clear();
        return ;
    }

    foundPlate->Learning();

    QMessageBox::information(this, "成功", "\n成功归还该车牌\n", QMessageBox::Ok);

    QString display = Display(foundPlate);

    ui->textBrowser->setText(display);
}
