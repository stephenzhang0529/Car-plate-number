#include "find.h"
#include "ui_find.h"

char _cityindex[14] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P'};

Find::Find(QMap<QString, int>* Ir, SeqList<plate*>* lp, QMap<char, QPair<int, int>>* ci, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Find),
    licensePlates(lp),
    cityIndex(ci),
    Is_repeated(Ir)
{
    ui->setupUi(this);

    QStringList cityList;
    cityList<<"  不知道"<<"  沈 阳"<<"  大 连"<<"  鞍 山"<<"  抚 顺"<<"  本 溪"<<"  丹 东"<<"  锦 州"<<"  营 口"<<"  阜 新"<<"  辽 阳"<<"  盘 锦"<<"  铁 岭"<<"  朝 阳"<<"  葫芦岛";
    ui->comboBox_city->addItems(cityList);
}

Find::~Find()
{
    delete ui;
}

void Find::on_pushButton_exit_clicked()
{
    ui->lineEdit_input->clear();
    ui->textBrowser->clear();
    emit backToMainWindow();
    this -> hide();
}


int Find::HalfFind(char city, QString plateNumber)
{
    auto l_and_r = cityIndex->value(city);
    int l = l_and_r.first, r = l_and_r.second;

    while(l < r)
    {
        int mid = (l + r) >> 1;
        if(plateNumber_cmp(plateNumber, (*licensePlates->SqList_at(mid))->GetPlateNumber()))
        {
            r = mid;
        }
        else
        {
            l = mid + 1;
        }
    }

    return l;
}




void Find::on_pushButton_find_clicked()
{
    if(!licensePlates->Issorted())
    {
        radixSort(*licensePlates, *cityIndex, 7);
        licensePlates->SqList_besorted();
    }

    if(!ui->lineEdit_input->text().isEmpty())
    {
        QString plateNumber = ui->lineEdit_input->text().toUpper();

        int plateIndex = -1;

        if(!Is_plate_right(plateNumber))
        {
            QMessageBox::critical(this, "警告", "\n车牌错误\n", QMessageBox::Ok);
            ui->lineEdit_input->clear();
            return ;
        }

        int city_index = ui->comboBox_city->currentIndex();

        if(!city_index)
        {
            QList<int> findIdx;
            QStringList plateNumbers;

            for(int idx = 0; idx < 14; idx ++)
            {
                if(Is_repeated->contains(_cityindex[idx] + plateNumber) && Is_repeated->value(_cityindex[idx] + plateNumber) == 1)
                {
                    findIdx.append(idx);
                    QString x = QString("辽%1 ").arg(_cityindex[idx]);
                    x += plateNumber;
                    plateNumbers.append(x);
                }
            }

            if (findIdx.size() > 1)
            {
                   bool ok;


                   QString selectedPlate = QInputDialog::getItem(this,"选择车牌号", "请选择一个车牌号：", plateNumbers, 0, false, &ok);
                   if (ok && !selectedPlate.isEmpty())
                   {
                       int selectedIndex = plateNumbers.indexOf(selectedPlate);
                       plateIndex = HalfFind(_cityindex[findIdx[selectedIndex]], plateNumber);
                   }
                   else
                   {
                       QMessageBox::warning(this, "警告", "\n未选择车牌\n", QMessageBox::Ok);
                       ui->lineEdit_input->clear();
                       return ;
                   }
            }
            else if (findIdx.size() == 1)
            {
               plateIndex = HalfFind(_cityindex[findIdx.first()], plateNumber);
            }
            else
            {
                QMessageBox::critical(this, "警告", "\n无此车牌\n", QMessageBox::Ok);
                ui->lineEdit_input->clear();
                return ;
            }
        }
        else
        {
            if(Is_repeated->contains(_cityindex[city_index - 1] + plateNumber) && Is_repeated->value(_cityindex[city_index - 1] + plateNumber) == 1)
            {
                plateIndex = HalfFind(_cityindex[city_index - 1], plateNumber);
            }
            else
            {
                QMessageBox::critical(this, "警告", "\n无此车牌\n", QMessageBox::Ok);
                ui->lineEdit_input->clear();
                return ;
            }
        }

        // 显示找到的车牌
        QMessageBox::information(this, "成功", "\n成功查询到该车牌\n", QMessageBox::Ok);

        plate* findPlate = *licensePlates->SqList_at(plateIndex);

        QString display = "   查询到的车牌   \n\n";
        display += QString("车牌号: 辽%1 ").arg(findPlate->GetPlateCity());
        display += plateNumber;
        display += "\n\n";
        display += QString("当前扣分: %1 分\n\n").arg(QString::number(12 - findPlate->GetPlateScore()));
        display += QString("当前状态: %1").arg(findPlate->GetPlateState());
        ui->textBrowser->setText(display);
    }
    else
    {
        ui->lineEdit_input->setFocus();
        return;
    }
}
