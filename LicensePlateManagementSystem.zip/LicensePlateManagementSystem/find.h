#ifndef FIND_H
#define FIND_H

#include <QWidget>
#include <QMap>
#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>
#include <QInputDialog>
#include <QTextStream>
#include "plate.h"
#include "plate.h"
#include "seqlist.h"
#include "radixsort.h"


namespace Ui {
class Find;
}

class Find : public QWidget
{
    Q_OBJECT

public:
    explicit Find(QMap<QString, int>* Ir, SeqList<plate*>* lp, QMap<char, QPair<int, int>>* ci, QWidget *parent = nullptr);
    ~Find();
    int HalfFind(char city, QString plateNumber);

private slots:
    void on_pushButton_exit_clicked();

    void on_pushButton_exit_3_clicked();

    void on_pushButton_find_clicked();

signals:
    void backToMainWindow();
    void sortSignal();

private:
    Ui::Find *ui;
    SeqList<plate*>* licensePlates;
    QMap<char, QPair<int, int>>* cityIndex;
    QMap<QString, int>* Is_repeated;
};

#endif // FIND_H
