#include "input.h"
#include "ui_input.h"

char cityindex[14] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P'};

Input::Input(QMap<QString, int> *Ir, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Input),
    Is_repeated(Ir)
{
    ui->setupUi(this);

    connect(this, &Input::destroyed, this, &Input::backToMainWindow);

    QStringList cityList;
    cityList<<"  沈 阳"<<"  大 连"<<"  鞍 山"<<"  抚 顺"<<"  本 溪"<<"  丹 东"<<"  锦 州"<<"  营 口"<<"  阜 新"<<"  辽 阳"<<"  盘 锦"<<"  铁 岭"<<"  朝 阳"<<"  葫芦岛";
    ui->comboBox_city->addItems(cityList);
}

Input::~Input()
{
    delete ui;
}

void Input::closeEvent(QCloseEvent *event)
{
    emit backToMainWindow(); // 发射信号回到主窗口
    QWidget::closeEvent(event); // 处理关闭事件
}

void Input::on_pushButton_manul_clicked()
{
    if(!ui->lineEdit_input->text().isEmpty())
    {
        // 获取城市
        int city_index = ui->comboBox_city->currentIndex();
        char city = cityindex[city_index];

        QString dealtext = ui->lineEdit_input->text();
        dealtext = dealtext.toUpper();

        if(!Is_plate_right(dealtext))
        {
            QMessageBox::critical(this, "警告", "\n车牌错误\n", QMessageBox::Ok);
            ui->lineEdit_input->clear();
            return ;
        }

        if(Is_repeated->contains(city + dealtext) && Is_repeated->value(city + dealtext) == 1)
        {
            QMessageBox::critical(this, "警告", "\n车牌重复\n", QMessageBox::Ok);
            ui->lineEdit_input->clear();
            return ;
        }

        plate* new_plate = new plate(dealtext, city);

        QMessageBox::StandardButton mBox;
        mBox = QMessageBox::question(this, "询问", QString("\n是否将车牌 辽%1 %2 录入\n").arg(city).arg(dealtext), QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
        if(mBox != QMessageBox::Yes)
        {
            ui->lineEdit_input->clear();
            return ;
        }
        QMessageBox::information(this, "成功", "\n成功读入该车牌\n", QMessageBox::Ok);
        qDebug()<<"辽"<<new_plate->GetPlateCity()<<" "<<new_plate->GetPlateNumber();
        (*Is_repeated)[city + dealtext] = 1;
        ui->lineEdit_input->clear();
        emit plateAdded(new_plate);
    }
    else
    {
        ui->lineEdit_input->setFocus();
        return;
    }
}

void Input::on_pushButton_file_clicked()
{
    QString filename=QFileDialog::getOpenFileName(this,"选择一个文件",
    QCoreApplication::applicationFilePath(),"*.txt");

    if(filename.isEmpty())
    {
        QMessageBox::warning(this,"提示","\n未选择文件\n");
    }
    else
    {
        QFile file(filename);
        if (!file.open(QIODevice::ReadOnly))
        {
            QMessageBox::critical(this, "错误", "文件打开失败");
            return;
        }
        QTextStream in(&file);

        QString display = "将要添加的车(按下确定输入按钮后录入):";

        while (!in.atEnd())
        {
            QString line = in.readLine().trimmed();

            if (line.isEmpty())
                continue;

            QStringList lineData = line.split(" ");

            QString platenumber = lineData[1].toUpper();
            if(!Is_plate_right(platenumber))
                continue;

            char city = lineData[0][0].toLatin1();
            if(Is_repeated->contains(city + platenumber) && Is_repeated->value(city + platenumber) == 1)
                    continue;

            (*Is_repeated)[city + platenumber] = 1;
            qDebug() << line;
            display += '\n' + QString("辽%1").arg(city) + " " + platenumber;
        }

        file.close();
        ui->textBrowser->setText(display);
    }
}

void Input::on_pushButton_exit_clicked()
{
    emit backToMainWindow();
    this -> hide();
}

void Input::on_pushButton_ensure_clicked()
{
    QString text = ui->textBrowser->toPlainText();  // 获取文本框中的所有内容
    QStringList lines = text.split('\n');

    int cnt = 0;

    for (int i = 1; i < lines.size(); i ++)
    {
        QStringList line = lines[i].split(" ");

        QString platenumber = line[1];
        char platecity = line[0][1].toLatin1();

        qDebug()<<platenumber<<" "<<platecity;

        plate* new_plate = new plate(platenumber, platecity);
        emit plateAdded(new_plate);

        cnt ++;
    }

    QMessageBox::information(this, "成功", QString("\n成功读入%1个车牌\n").arg(QString::number(cnt)), QMessageBox::Ok);
    ui->textBrowser->clear();
}

void Input::on_pushButton_exit_2_clicked()
{
    QString text = ui->textBrowser->toPlainText();  // 获取文本框中的所有内容
    QStringList lines = text.split('\n');

    for (int i = 1; i < lines.size(); i ++)
    {
        QStringList line = lines[i].split(" ");
        QString platenumber = line[1];
        char platecity = line[0][1].toLatin1();

        (*Is_repeated)[platecity + platenumber] = 0;
    }
    ui->textBrowser->clear();
}
