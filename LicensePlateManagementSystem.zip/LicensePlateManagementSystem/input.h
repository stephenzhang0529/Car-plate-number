#ifndef INPUT_H
#define INPUT_H

#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>
#include <QTextStream>
#include <QMap>
#include "plate.h"

namespace Ui {
class Input;
}

class Input : public QWidget
{
    Q_OBJECT

public:
    explicit Input(QMap<QString, int> *Ir, QWidget *parent = nullptr);
    ~Input();
    void closeEvent(QCloseEvent *event);

signals:
    void backToMainWindow();
    void plateAdded(plate* p);

private slots:
    void on_pushButton_manul_clicked();

    void on_pushButton_file_clicked();

    void on_pushButton_exit_clicked();

    void on_pushButton_ensure_clicked();

    void on_pushButton_exit_2_clicked();


private:
    Ui::Input *ui;
    QMap<QString, int> *Is_repeated;
};




#endif // INPUT_H
