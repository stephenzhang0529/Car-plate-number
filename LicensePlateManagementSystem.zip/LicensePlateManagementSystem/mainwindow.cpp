#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , licensePlates()
{
    ui->setupUi(this);

    input = new Input(&Is_repeated);
    connect(input, &Input::backToMainWindow, this, &MainWindow::show); // 当接收到 backToMainWindow 信号时显示主窗口
    connect(input, &Input::plateAdded, this, &MainWindow::onPlateAdded);

    find = new Find(&Is_repeated, &licensePlates, &cityIndex);
    connect(find, &Find::backToMainWindow, this, &MainWindow::show); // 当接收到 backToMainWindow 信号时显示主窗口
    connect(find, &Find::sortSignal, this, &MainWindow::onSort);




}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_input_clicked()
{
    this -> hide();
    input -> show();
}

void MainWindow::onPlateAdded(plate* p)
{
    if (p)
    {
        licensePlates.SqList_push(p);  // 将新的车牌信息添加到顺序表
        // qDebug() << "车牌号： " << p->GetPlateNumber();
        // qDebug() << licensePlates.Capacity()<< "  " << licensePlates.Size();

        // 此时变为乱序
        licensePlates.SqList_beunsorted();
    }
}

void MainWindow::onSort()
{
    radixSort(licensePlates,cityIndex, 7);
}


void MainWindow::on_pushButton_print_clicked()
{
    for(int i = 0; i < licensePlates.Size(); i ++)
    {
        plate *p = *licensePlates.SqList_at(i);
        qDebug()<<"辽"<<p->GetPlateCity()<<" "<< p->GetPlateNumber();
    }
    qDebug()<<"一共有"<<licensePlates.Size()<<"个车牌";
}


void MainWindow::on_pushButton_find_clicked()
{
    this -> hide();
    find -> show();
}
