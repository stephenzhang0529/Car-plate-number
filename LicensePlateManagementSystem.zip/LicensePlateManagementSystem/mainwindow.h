#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDebug>
#include <QMap>
#include <QPair>
#include <cstring>
#include "input.h"
#include "seqlist.h"
#include "plate.h"
#include "radixsort.h"
#include "find.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_input_clicked();

    void onPlateAdded(plate* p);

    void onSort();

    void on_pushButton_sort_clicked();

    void on_pushButton_print_clicked();

    void on_pushButton_find_clicked();

private:
    Ui::MainWindow *ui;
private:
    Input *input = nullptr;
    Find *find = nullptr;
    SeqList<plate*> licensePlates;
    QMap<char, QPair<int, int>> cityIndex;
    QMap<QString, int> Is_repeated;

};
#endif // MAINWINDOW_H
