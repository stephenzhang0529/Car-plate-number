#include "plate.h"

plate::plate(QString number, char city)
{
    plate_number = number;
    score = 12;
    is_withdraw = false;
    plate_city = city;
}

bool plate::Deduction(int cut_socore)
{
    score -= cut_socore;
    if(Is_withdraw())
    {
        is_withdraw = true;
    }
    score = score >= 0 ? score : 0;
    return true;
}

bool plate::Is_withdraw()
{
    return score <= 0;
}

bool plate::Learning()
{
    score = 12;
    is_withdraw = false;
    return true;
}

bool Is_plate_right(QString PlateNumber)
{
    int length = PlateNumber.size();

    if(!(length == 5 || length == 6))return false ;

    for(int i = 0; i < length; i ++)
    {
        if(!(('0' <= PlateNumber[i] && PlateNumber[i] <= '9') || ('A' <= PlateNumber[i] && PlateNumber[i] <= 'Z')))
        {
            return false;
        }
    }
    return true;
}

bool plateNumber_cmp(QString plateNumber1, QString plateNumber2)
{
    for(int i = 0; i < 5; i ++)
    {
        if(plateNumber1[i] < plateNumber2[i])
        {
            return true;
        }
        else if(plateNumber1[i] > plateNumber2[i])
        {
            return false;
        }
    }

    if(plateNumber1.size() == 6 && plateNumber2.size() == 6)
    {
        if(plateNumber1[5] <= plateNumber2[5])
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    if(plateNumber1.size() <= plateNumber2.size())
    {
        return true;
    }
    else
    {
        return false;
    }

    return true;
}
