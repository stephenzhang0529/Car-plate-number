#ifndef PLATE_H
#define PLATE_H

#include <QString>
#include <QDebug>

class plate
{
private:
    QString plate_number;
    int score;
    bool is_withdraw;
    char plate_city;

public:
    plate(QString number, char city);
    bool Deduction(int cut_socore);       // 扣分
    bool Is_withdraw();                   // 车牌是否被吊销
    bool Learning();                      // 学习

    // 获取车牌号
    QString GetPlateNumber() const { return plate_number; }
    // 获取城市
    char GetPlateCity() const { return plate_city; }
    // 获取分数
    int GetPlateScore() const { return score; }

    QString GetPlateState() const{
        if(is_withdraw)return QString("被暂扣");
        return QString("正常");
    }
};

bool Is_plate_right(QString PlateNumber);

bool plateNumber_cmp(QString plateNumber1, QString plateNumber2);

#endif // PLATE_H
