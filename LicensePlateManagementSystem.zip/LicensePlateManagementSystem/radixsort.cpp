#include "radixsort.h"

Node static_List[MAXSIZE];       // 静态链表
int buckets[BUCKETS];           // 桶数组

void radixSort(SeqList<plate*>& licensePlates, QMap<char, QPair<int, int>>& cityIndex, int maxLength)
{
    int static_size = licensePlates.Size();
    qDebug() <<licensePlates.Size();
    qDebug() <<static_size;

    for (int pos = maxLength - 1; pos >= 0; pos --)
    {
        memset(buckets, -1, sizeof(buckets));
        for(int j = 0; j < static_size; j ++)
        {
            static_List[j].data = *licensePlates.SqList_at(j);
            static_List[j].next = -1;
        }

        // 从后往前遍历，保证排序的稳定
        for(int j = static_size - 1; j >= 0; j --)
        {
            QString plateNumber = static_List[j].data->GetPlateNumber();
            int bucketIdx;

            if(pos == 0)
            {
                bucketIdx = static_List[j].data->GetPlateCity() - 'A';
            }
            else
            {
                if(pos - 1 >= plateNumber.size())
                {
                    bucketIdx = 0;
                }
                else
                {
                    char nowchar = plateNumber[pos - 1].toLatin1();

                    if(nowchar >= 'A' && nowchar <= 'Z')
                    {
                        bucketIdx = nowchar - 'A' + 11;
                    }
                    else
                    {
                        bucketIdx = nowchar - '0' + 1;
                    }
                }
            }


            // 插入桶中
            static_List[j].next = buckets[bucketIdx];
            buckets[bucketIdx] = j;
        }

        // 清空顺序表
        licensePlates.SqList_clear();

        // 将排序结果写回顺序表
        int end = 0;
        int start = 0;

        for(int i = 0; i < BUCKETS; i ++)
        {
            int p = buckets[i];

            while(p != -1)
            {
                licensePlates.SqList_push(static_List[p].data);
                p = static_List[p].next;

                // 最后一次录入确定城市索引
                if(!pos)
                {
                    end++;
                }
            }

            if(!pos && i < 26)
            {
                cityIndex['A' + i] = {start, end - 1};
                start = end;
            }
        }

    }

    licensePlates.SqList_besorted();

    qDebug()<<licensePlates.Size();
    qDebug()<<cityIndex;
}
