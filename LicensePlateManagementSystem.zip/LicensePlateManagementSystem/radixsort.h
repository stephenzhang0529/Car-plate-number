#ifndef RADIXSORT_H
#define RADIXSORT_H

#define MAXSIZE 100000 // 静态链表长度
#define BUCKETS 37     //数字10 + 字母 26 + 空1

#include <qdebug.h>
#include "seqlist.h"
#include "plate.h"


typedef struct _Node
{
    plate* data;    // 数据域
    int next;       // 指针域，指向下一个节点
} Node;


void radixSort(SeqList<plate*>& licensePlates, QMap<char, QPair<int, int>>& cityIndex, int maxLength);

#endif // RADIXSORT_H
