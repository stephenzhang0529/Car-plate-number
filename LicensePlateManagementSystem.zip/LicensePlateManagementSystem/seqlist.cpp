#include "seqlist.h"
#define MaxSize 100

template<class Data>
SeqList<Data>::SeqList()
{
    datas = new Data[MaxSize];
    size = 0;
    capacity = MaxSize;
}

template<class Data>
SeqList<Data>::~SeqList()
{
    delete []datas;
}

template<class Data>
int SeqList<Data>::Size()
{
    return Size;
}

template<class Data>
bool SeqList<Data>::SqList_grow()
{
    int newCapacity = capacity * 1.5;    //扩大1.5倍
    Data* temp = new Data[newCapacity * sizeof(int)];

    for (int i = 0; i < size; i++)
        temp[i] = datas[i];

    datas = temp;
    capacity = newCapacity;
    return true;
}

template<class Data>
bool SeqList<Data>::SqList_push(Data e)
{
    //判断顺序表是否已满,若已满则扩容失败
    if (capacity == size && !SqList_grow())
    {
        qDebug()<<"Error: SqList is full and can't grow\n";
        exit(1);
    }
    datas[size] = e;
    size++;
}
