#include "statistics.h"
#include "ui_statistics.h"

int index[16] = {0, 1, 2, 3, 4, 5, 6, 7, 0, 8, 9, 10, 11, 12, 0, 13};

Statistics::Statistics(SeqList<plate*>* lp, QMap<char, QPair<int, int>>* ci, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Statistics),
    licensePlates(lp),
    barChart_Quantity(new QChart),
    barChart_Category(new QChart),
    barChart_Deduction(new QChart),
    cityIndex(ci)
{
    ui->setupUi(this);

    connect(this, &Statistics::destroyed, this, &Statistics::backToMainWindow);
    initChart();

    QStringList optionList;
    optionList<<"  数 量"<<"  类 别"<<"  扣 分";
    ui->comboBox_options->addItems(optionList);
}

Statistics::~Statistics()
{
    delete ui;
}

void Statistics::initChart()
{
    initBarChart_Category();
    initBarChart_Quantity();
    initBarChart_Deduction();
}

void Statistics::initDisplay()
{
    if(!licensePlates->Issorted())
    {
        radixSort(*licensePlates, *cityIndex, 7);
        licensePlates->SqList_besorted();
    }

    QString display = QString("   当前已录入的车牌(共计%1个)\n\n").arg(licensePlates->Size());

    for(int i = 0; i < licensePlates->Size(); i++)
    {
        plate* p = *(licensePlates->SqList_at(i));
        display += QString("辽%1 ").arg(p->GetPlateCity());
        display += p->GetPlateNumber();
        display += "\n";
    }

    ui->textBrowser->setText(display);

}

void Statistics::closeEvent(QCloseEvent *event)
{
    emit backToMainWindow();
    QWidget::closeEvent(event);
}


void Statistics::on_pushButton_exit_clicked()
{
    emit backToMainWindow();
    this -> hide();
}

void Statistics::initBarChart_Quantity()
{
    QVector<qreal> data1(14, 0);
    int maxh = 0;
    for (int i = 0; i < licensePlates->Size(); i++)
    {
        plate* p = *(licensePlates->SqList_at(i));
        data1[index[p->GetPlateCity() - 'A']] += 1;
        maxh = maxh > data1[index[p->GetPlateCity() - 'A']]? maxh : data1[index[p->GetPlateCity() - 'A']];
    }
    qDebug() << data1;
    QBarSet *set0 = new QBarSet("车牌的数量");
    for (const qreal &value : data1)
    {
        *set0 << value;
    }

    QFont font;
    font.setPointSize(15);
    font.setBold(true);


    QBarSeries *series = new QBarSeries();
    series->append(set0);
    series->setBarWidth(0.8);
    series->setLabelsVisible(true);
    barChart_Quantity->addSeries(series);
    barChart_Quantity->setTitle("每个地方的车牌数量");
    barChart_Quantity->setTitleFont(font);

    QStringList categories;
    categories <<"沈 阳"<<"大 连"<<"鞍 山"<<"抚 顺"<<"本 溪"<<"丹 东"<<"锦 州"<<"营 口"<<"阜 新"<<"辽 阳"<<"盘 锦"<<"铁 岭"<<"朝 阳"<<"葫芦岛";

    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    barChart_Quantity->createDefaultAxes();
    barChart_Quantity->setAxisX(axisX, series);
    font.setPointSize(11);
    axisX->setLabelsFont(font);

    QValueAxis *axisY = new QValueAxis();
    axisY->setRange(0, maxh + 1);
    axisY->setTickCount(maxh + 2);
    axisY->setLabelFormat("%d");
    axisY->setLabelsFont(QFont("Arial", 12, QFont::Bold));
    barChart_Quantity->setAxisY(axisY, series);


    barChart_Quantity->legend()->setVisible(true);
    barChart_Quantity->legend()->setAlignment(Qt::AlignBottom);//设置图例的显示位置在底部
}

void Statistics::initBarChart_Category()
{
    QVector<qreal> common(14, 0), tram(14, 0);
    int maxh = 0;
    for (int i = 0; i < licensePlates->Size(); i++)
    {
        plate* p = *(licensePlates->SqList_at(i));
        if(p->GetPlateNumber().size() == 5)
        {
            common[index[p->GetPlateCity() - 'A']] += 1;
            maxh = maxh > common[index[p->GetPlateCity() - 'A']]? maxh : common[index[p->GetPlateCity() - 'A']];
        }
        else
        {
            tram[index[p->GetPlateCity() - 'A']] += 1;
            maxh = maxh > tram[index[p->GetPlateCity() - 'A']]? maxh : tram[index[p->GetPlateCity() - 'A']];
        }
    }
    QBarSet *setCommon = new QBarSet("普通车车牌的数量");
    for (const qreal &value : common)
    {
        *setCommon << value;
    }

    QBarSet *setTram = new QBarSet("电车车牌的数量");
    for (const qreal &value : common)
    {
        *setTram << value;
    }

    QFont font;
    font.setPointSize(15);
    font.setBold(true);

    QBarSeries *series = new QBarSeries();
    series->append(setCommon);
    series->append(setTram);
    series->setBarWidth(0.8);
    series->setLabelsVisible(true);

    barChart_Category->addSeries(series);
    barChart_Category->setTitle("每个地方的车牌类别的数量(普通车/电车)");
    barChart_Category->setTitleFont(font);

    QStringList categories;
    categories <<"沈 阳"<<"大 连"<<"鞍 山"<<"抚 顺"<<"本 溪"<<"丹 东"<<"锦 州"<<"营 口"<<"阜 新"<<"辽 阳"<<"盘 锦"<<"铁 岭"<<"朝 阳"<<"葫芦岛";


    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    barChart_Category->createDefaultAxes();
    barChart_Category->setAxisX(axisX, series);
    font.setPointSize(11);
    axisX->setLabelsFont(font);

    QValueAxis *axisY = new QValueAxis();
    axisY->setRange(0, maxh + 1);
    axisY->setTickCount(maxh + 2);
    axisY->setLabelFormat("%d");
    axisY->setLabelsFont(QFont("Arial", 12, QFont::Bold));
    barChart_Category->setAxisY(axisY, series);


    barChart_Category->legend()->setVisible(true);
    barChart_Category->legend()->setAlignment(Qt::AlignBottom);//设置图例的显示位置在底部

}

void Statistics::initBarChart_Deduction()
{
    QVector<qreal> score(13, 0);
    int maxh = 0;
    for (int i = 0; i < licensePlates->Size(); i++)
    {
        plate* p = *(licensePlates->SqList_at(i));

        score[p->GetPlateScore()] += 1;
        maxh = maxh > score[p->GetPlateScore()]? maxh : score[p->GetPlateScore()];
    }

    QBarSet *setScore = new QBarSet("已扣分数");
    for (const qreal &value : score)
    {
        *setScore << value;
    }

    QFont font;
    font.setPointSize(13);
    font.setBold(true);

    QBarSeries *series = new QBarSeries();
    series->append(setScore);
    series->setBarWidth(0.8);
    series->setLabelsVisible(true);

    barChart_Deduction->addSeries(series);
    barChart_Deduction->setTitle("扣分车牌的数量");
    barChart_Deduction->setTitleFont(font);
    barChart_Deduction->setMargins(QMargins(30, 10, 10, 30));

    QStringList categories;
    for(int i=0 ; i < 13; i++)
    {
        categories << QString("已扣%1分").arg(QString::number(i));
    }


    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    axisX->setLabelsAngle(-45);
    barChart_Deduction->createDefaultAxes();
    barChart_Deduction->setAxisX(axisX, series);
    font.setPointSize(9);
    axisX->setLabelsFont(font);

    QValueAxis *axisY = new QValueAxis();
    axisY->setRange(0, maxh + 1);
    axisY->setTickCount(maxh + 2);
    axisY->setLabelFormat("%d");
    axisY->setLabelsFont(QFont("Arial", 12, QFont::Bold));
    barChart_Deduction->setAxisY(axisY, series);


    barChart_Deduction->legend()->setVisible(true);
    barChart_Deduction->legend()->setAlignment(Qt::AlignBottom);
}

void Statistics::update()
{
    updateBarChart_Quantity();
    updateBarChart_Category();
    updateBarChart_Deduction();

    ui->barChart->setChart(barChart_Quantity);
}

void Statistics::updateBarChart_Quantity()
{
    QBarSeries* series = qobject_cast<QBarSeries*>(barChart_Quantity->series().first());
    QBarSet *set0 = series->barSets().first();

    QVector<qreal> newData(14, 0);
    int maxh = 0;
    for (int i = 0; i < licensePlates->Size(); i++)
    {
        plate* p = *(licensePlates->SqList_at(i));
        newData[index[p->GetPlateCity() - 'A']] += 1;
        maxh = maxh > newData[index[p->GetPlateCity() - 'A']]? maxh : newData[index[p->GetPlateCity() - 'A']];
    }

    for(int i = 0; i < 14; i++)
    {
        set0->replace(i, newData[i]);
    }

    QValueAxis* axisY = qobject_cast<QValueAxis*>(barChart_Quantity->axisY());
    axisY->setRange(0, maxh + 1);
    axisY->setTickCount(maxh + 2);
}

void Statistics::updateBarChart_Category()
{
    QBarSeries* series = qobject_cast<QBarSeries*>(barChart_Category->series().first());
    QBarSet *setCommom = series->barSets().first();
    QBarSet *setTram = series->barSets().back();

    QVector<qreal> common(14, 0), tram(14, 0);
    int maxh = 0;
    for (int i = 0; i < licensePlates->Size(); i++)
    {
        plate* p = *(licensePlates->SqList_at(i));
        if(p->GetPlateNumber().size() == 5)
        {
            common[index[p->GetPlateCity() - 'A']] += 1;
            maxh = maxh > common[index[p->GetPlateCity() - 'A']]? maxh : common[index[p->GetPlateCity() - 'A']];
        }
        else
        {
            tram[index[p->GetPlateCity() - 'A']] += 1;
            maxh = maxh > tram[index[p->GetPlateCity() - 'A']]? maxh : tram[index[p->GetPlateCity() - 'A']];
        }
    }

    for(int i = 0; i < 14; i++)
    {
        setCommom->replace(i, common[i]);
        setTram->replace(i, tram[i]);
    }

    QValueAxis* axisY = qobject_cast<QValueAxis*>(barChart_Category->axisY());
    axisY->setRange(0, maxh + 1);
    axisY->setTickCount(maxh + 2);
}

void Statistics::updateBarChart_Deduction()
{
    QBarSeries* series = qobject_cast<QBarSeries*>(barChart_Deduction->series().first());
    QBarSet *set0 = series->barSets().first();

    QVector<qreal> score(13, 0);
    int maxh = 0;
    for (int i = 0; i < licensePlates->Size(); i++)
    {
        plate* p = *(licensePlates->SqList_at(i));

        score[p->GetPlateScore()] += 1;
        maxh = maxh > score[p->GetPlateScore()]? maxh : score[p->GetPlateScore()];
    }


    for(int i = 0; i < 13; i++)
    {
        set0->replace(i, score[i]);
    }

    QValueAxis* axisY = qobject_cast<QValueAxis*>(barChart_Deduction->axisY());
    axisY->setRange(0, maxh + 1);
    axisY->setTickCount(maxh + 2);
}

void Statistics::on_comboBox_options_activated(int index)
{
    switch (index)
    {
    case 0:
        ui->barChart->setChart(barChart_Quantity);
        break;
    case 1:
        ui->barChart->setChart(barChart_Category);
        break;
    case 2:
        ui->barChart->setChart(barChart_Deduction);
    default:
        return ;
    }
}
