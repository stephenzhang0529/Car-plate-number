#ifndef STATISTICS_H
#define STATISTICS_H

#include <QWidget>
#include <QCloseEvent>
#include <QtCharts>
#include <QDebug>
#include "algorithms.h"



QT_CHARTS_USE_NAMESPACE

namespace Ui {
class Statistics;
}

class Statistics : public QWidget
{
    Q_OBJECT

public:
    explicit Statistics(SeqList<plate*>* lp, QMap<char, QPair<int, int>>* ci, QWidget *parent = nullptr);
    ~Statistics();
    void closeEvent(QCloseEvent *event);
    void initBarChart_Quantity();
    void initBarChart_Category();
    void initBarChart_Deduction();
    void initChart();
    void updateBarChart_Quantity();
    void updateBarChart_Category();
    void updateBarChart_Deduction();


signals:
    void backToMainWindow();

public slots:

    void initDisplay();

    void update();

private slots:
    void on_pushButton_exit_clicked();

    void on_comboBox_options_activated(int index);

private:
    Ui::Statistics *ui;
    SeqList<plate*>* licensePlates;
    QChart* barChart_Quantity;
    QChart* barChart_Category;
    QChart* barChart_Deduction;
    QMap<char, QPair<int, int>>* cityIndex;

};

#endif // STATISTICS_H
