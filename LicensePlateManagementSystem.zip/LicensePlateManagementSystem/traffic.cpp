#include "traffic.h"
#include "ui_traffic.h"

Traffic::Traffic(QMap<QString, int>* Ir, SeqList<plate*>* lp, QMap<char, QPair<int, int>>* ci, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Traffic),
    licensePlates(lp),
    cityIndex(ci),
    Is_repeated(Ir)
{
    ui->setupUi(this);
}

Traffic::~Traffic()
{
    delete ui;
}
