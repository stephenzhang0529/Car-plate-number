#ifndef TRAFFIC_H
#define TRAFFIC_H

#include <QWidget>
#include "seqlist.h"
#include "plate.h"

namespace Ui {
class Traffic;
}

class Traffic : public QWidget
{
    Q_OBJECT

public:
    explicit Traffic(QMap<QString, int>* Ir, SeqList<plate*>* lp, QMap<char, QPair<int, int>>* ci, QWidget *parent = nullptr);
    ~Traffic();

private:
    Ui::Traffic *ui;
    SeqList<plate*>* licensePlates;
    QMap<char, QPair<int, int>>* cityIndex;
    QMap<QString, int>* Is_repeated;
};

#endif // TRAFFIC_H
